﻿namespace TH05_Edward_Geraldo
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            dgv_Product = new DataGridView();
            dgv_Category = new DataGridView();
            btn_All = new Button();
            btn_Filter = new Button();
            cbox_Filters = new ComboBox();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            tb_namaProduct = new TextBox();
            cbox_category = new ComboBox();
            tb_harga = new TextBox();
            tb_stock = new TextBox();
            btn_addProduct = new Button();
            btn_removeProduct = new Button();
            btn_editProduct = new Button();
            label8 = new Label();
            tb_namaCategory = new TextBox();
            btn_addCategory = new Button();
            btn_removeCategory = new Button();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)dgv_Product).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgv_Category).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(25, 23);
            label1.Name = "label1";
            label1.Size = new Size(62, 19);
            label1.TabIndex = 0;
            label1.Text = "Product";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(587, 23);
            label2.Name = "label2";
            label2.Size = new Size(72, 19);
            label2.TabIndex = 1;
            label2.Text = "Category";
            // 
            // dgv_Product
            // 
            dgv_Product.AllowUserToAddRows = false;
            dgv_Product.AllowUserToDeleteRows = false;
            dgv_Product.AllowUserToResizeColumns = false;
            dgv_Product.AllowUserToResizeRows = false;
            dgv_Product.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_Product.EditMode = DataGridViewEditMode.EditProgrammatically;
            dgv_Product.Location = new Point(25, 68);
            dgv_Product.Margin = new Padding(3, 2, 3, 2);
            dgv_Product.MultiSelect = false;
            dgv_Product.Name = "dgv_Product";
            dgv_Product.RowHeadersVisible = false;
            dgv_Product.RowHeadersWidth = 51;
            dgv_Product.RowTemplate.Height = 29;
            dgv_Product.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgv_Product.Size = new Size(496, 181);
            dgv_Product.TabIndex = 2;
            dgv_Product.CellClick += dgv_Product_CellClick;
            // 
            // dgv_Category
            // 
            dgv_Category.AllowUserToAddRows = false;
            dgv_Category.AllowUserToDeleteRows = false;
            dgv_Category.AllowUserToResizeColumns = false;
            dgv_Category.AllowUserToResizeRows = false;
            dgv_Category.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_Category.EditMode = DataGridViewEditMode.EditProgrammatically;
            dgv_Category.Location = new Point(587, 68);
            dgv_Category.Margin = new Padding(3, 2, 3, 2);
            dgv_Category.MultiSelect = false;
            dgv_Category.Name = "dgv_Category";
            dgv_Category.RowHeadersVisible = false;
            dgv_Category.RowHeadersWidth = 51;
            dgv_Category.RowTemplate.Height = 29;
            dgv_Category.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgv_Category.Size = new Size(218, 145);
            dgv_Category.TabIndex = 3;
            dgv_Category.CellClick += dgv_Category_CellClick;
            // 
            // btn_All
            // 
            btn_All.Location = new Point(327, 41);
            btn_All.Margin = new Padding(3, 2, 3, 2);
            btn_All.Name = "btn_All";
            btn_All.Size = new Size(38, 21);
            btn_All.TabIndex = 4;
            btn_All.Text = "All";
            btn_All.UseVisualStyleBackColor = true;
            btn_All.Click += btn_All_Click;
            // 
            // btn_Filter
            // 
            btn_Filter.Location = new Point(374, 40);
            btn_Filter.Margin = new Padding(3, 2, 3, 2);
            btn_Filter.Name = "btn_Filter";
            btn_Filter.Size = new Size(53, 22);
            btn_Filter.TabIndex = 5;
            btn_Filter.Text = "Filter:";
            btn_Filter.UseVisualStyleBackColor = true;
            btn_Filter.Click += btn_Filter_Click;
            // 
            // cbox_Filters
            // 
            cbox_Filters.FormattingEnabled = true;
            cbox_Filters.Location = new Point(432, 41);
            cbox_Filters.Margin = new Padding(3, 2, 3, 2);
            cbox_Filters.Name = "cbox_Filters";
            cbox_Filters.Size = new Size(89, 23);
            cbox_Filters.TabIndex = 6;
            cbox_Filters.SelectedIndexChanged += cbox_Filters_SelectedIndexChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(24, 262);
            label3.Name = "label3";
            label3.Size = new Size(54, 19);
            label3.TabIndex = 7;
            label3.Text = "Details";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(24, 289);
            label4.Name = "label4";
            label4.Size = new Size(42, 15);
            label4.TabIndex = 8;
            label4.Text = "Nama:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(24, 320);
            label5.Name = "label5";
            label5.Size = new Size(58, 15);
            label5.TabIndex = 9;
            label5.Text = "Category:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(24, 345);
            label6.Name = "label6";
            label6.Size = new Size(42, 15);
            label6.TabIndex = 10;
            label6.Text = "Harga:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(25, 374);
            label7.Name = "label7";
            label7.Size = new Size(39, 15);
            label7.TabIndex = 11;
            label7.Text = "Stock:";
            // 
            // tb_namaProduct
            // 
            tb_namaProduct.Location = new Point(94, 286);
            tb_namaProduct.Margin = new Padding(3, 2, 3, 2);
            tb_namaProduct.Name = "tb_namaProduct";
            tb_namaProduct.Size = new Size(275, 23);
            tb_namaProduct.TabIndex = 12;
            // 
            // cbox_category
            // 
            cbox_category.FormattingEnabled = true;
            cbox_category.Location = new Point(94, 317);
            cbox_category.Margin = new Padding(3, 2, 3, 2);
            cbox_category.Name = "cbox_category";
            cbox_category.Size = new Size(120, 23);
            cbox_category.TabIndex = 13;
            // 
            // tb_harga
            // 
            tb_harga.Location = new Point(94, 345);
            tb_harga.Margin = new Padding(3, 2, 3, 2);
            tb_harga.Name = "tb_harga";
            tb_harga.Size = new Size(120, 23);
            tb_harga.TabIndex = 14;
            tb_harga.KeyPress += tb_harga_KeyPress;
            // 
            // tb_stock
            // 
            tb_stock.Location = new Point(94, 374);
            tb_stock.Margin = new Padding(3, 2, 3, 2);
            tb_stock.Name = "tb_stock";
            tb_stock.Size = new Size(120, 23);
            tb_stock.TabIndex = 15;
            tb_stock.KeyDown += tb_stock_KeyDown;
            tb_stock.KeyPress += tb_stock_KeyPress;
            // 
            // btn_addProduct
            // 
            btn_addProduct.BackColor = Color.Lime;
            btn_addProduct.ForeColor = Color.Black;
            btn_addProduct.Location = new Point(227, 345);
            btn_addProduct.Margin = new Padding(3, 2, 3, 2);
            btn_addProduct.Name = "btn_addProduct";
            btn_addProduct.Size = new Size(64, 50);
            btn_addProduct.TabIndex = 16;
            btn_addProduct.Text = "Add Product";
            btn_addProduct.UseVisualStyleBackColor = false;
            btn_addProduct.Click += btn_addProduct_Click;
            // 
            // btn_removeProduct
            // 
            btn_removeProduct.BackColor = Color.Red;
            btn_removeProduct.Location = new Point(374, 345);
            btn_removeProduct.Margin = new Padding(3, 2, 3, 2);
            btn_removeProduct.Name = "btn_removeProduct";
            btn_removeProduct.Size = new Size(64, 50);
            btn_removeProduct.TabIndex = 17;
            btn_removeProduct.Text = "Remove Product";
            btn_removeProduct.UseVisualStyleBackColor = false;
            btn_removeProduct.Click += btn_removeProduct_Click;
            // 
            // btn_editProduct
            // 
            btn_editProduct.BackColor = Color.Yellow;
            btn_editProduct.Location = new Point(300, 345);
            btn_editProduct.Margin = new Padding(3, 2, 3, 2);
            btn_editProduct.Name = "btn_editProduct";
            btn_editProduct.Size = new Size(64, 50);
            btn_editProduct.TabIndex = 18;
            btn_editProduct.Text = "Edit Product";
            btn_editProduct.UseVisualStyleBackColor = false;
            btn_editProduct.Click += btn_editProduct_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(589, 220);
            label8.Name = "label8";
            label8.Size = new Size(42, 15);
            label8.TabIndex = 19;
            label8.Text = "Nama:";
            label8.Click += label8_Click;
            // 
            // tb_namaCategory
            // 
            tb_namaCategory.Location = new Point(640, 218);
            tb_namaCategory.Margin = new Padding(3, 2, 3, 2);
            tb_namaCategory.Name = "tb_namaCategory";
            tb_namaCategory.Size = new Size(155, 23);
            tb_namaCategory.TabIndex = 20;
            tb_namaCategory.TextChanged += tb_namaCategory_TextChanged;
            // 
            // btn_addCategory
            // 
            btn_addCategory.BackColor = Color.Lime;
            btn_addCategory.Location = new Point(640, 243);
            btn_addCategory.Margin = new Padding(3, 2, 3, 2);
            btn_addCategory.Name = "btn_addCategory";
            btn_addCategory.Size = new Size(73, 40);
            btn_addCategory.TabIndex = 21;
            btn_addCategory.Text = "Add Category";
            btn_addCategory.UseVisualStyleBackColor = false;
            btn_addCategory.Click += btn_addCategory_Click;
            // 
            // btn_removeCategory
            // 
            btn_removeCategory.BackColor = Color.Red;
            btn_removeCategory.Location = new Point(722, 243);
            btn_removeCategory.Margin = new Padding(3, 2, 3, 2);
            btn_removeCategory.Name = "btn_removeCategory";
            btn_removeCategory.Size = new Size(73, 40);
            btn_removeCategory.TabIndex = 22;
            btn_removeCategory.Text = "Remove Category";
            btn_removeCategory.UseVisualStyleBackColor = false;
            btn_removeCategory.Click += btn_removeCategory_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.LightSalmon;
            pictureBox1.Image = Properties.Resources.kjw_coba;
            pictureBox1.Location = new Point(587, 289);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(218, 137);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 23;
            pictureBox1.TabStop = false;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightSlateGray;
            ClientSize = new Size(835, 431);
            Controls.Add(pictureBox1);
            Controls.Add(btn_removeCategory);
            Controls.Add(btn_addCategory);
            Controls.Add(tb_namaCategory);
            Controls.Add(label8);
            Controls.Add(btn_editProduct);
            Controls.Add(btn_removeProduct);
            Controls.Add(btn_addProduct);
            Controls.Add(tb_stock);
            Controls.Add(tb_harga);
            Controls.Add(cbox_category);
            Controls.Add(tb_namaProduct);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(cbox_Filters);
            Controls.Add(btn_Filter);
            Controls.Add(btn_All);
            Controls.Add(dgv_Category);
            Controls.Add(dgv_Product);
            Controls.Add(label2);
            Controls.Add(label1);
            ForeColor = Color.Black;
            Margin = new Padding(3, 2, 3, 2);
            Name = "MainForm";
            Text = "MainForm";
            Load += MainForm_Load;
            ((System.ComponentModel.ISupportInitialize)dgv_Product).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgv_Category).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private DataGridView dgv_Product;
        private DataGridView dgv_Category;
        private Button btn_All;
        private Button btn_Filter;
        private ComboBox cbox_Filters;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private TextBox tb_namaProduct;
        private ComboBox cbox_category;
        private TextBox tb_harga;
        private TextBox tb_stock;
        private Button btn_addProduct;
        private Button btn_removeProduct;
        private Button btn_editProduct;
        private Label label8;
        private TextBox tb_namaCategory;
        private Button btn_addCategory;
        private Button btn_removeCategory;
        private PictureBox pictureBox1;
    }
}