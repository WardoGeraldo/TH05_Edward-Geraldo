using System.ComponentModel;
using System.Data;

namespace TH05_Edward_Geraldo
{
    public partial class MainForm : Form
    {
        DataTable dtSaveProduct;
        DataTable dtShowProduct;
        DataTable dtCategory;
        int counter = 6;
        int indexChosen = 0;
        int categoryChosen = 0;
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            cbox_Filters.Enabled = false;
            dtSaveProduct = new DataTable();
            dtShowProduct = new DataTable();
            dtCategory = new DataTable();

            dtSaveProduct.Columns.Add("ID Product");
            dtSaveProduct.Columns.Add("Nama Product");
            dtSaveProduct.Columns.Add("Harga");
            dtSaveProduct.Columns.Add("Stock");
            dtSaveProduct.Columns.Add("ID Category");
            dtSaveProduct.Rows.Add("J001", "Jas Hitam", 100000, 10, "C1");
            dtSaveProduct.Rows.Add("T001", "T-Shirt Black Pink", 70000, 20, "C2");
            dtSaveProduct.Rows.Add("T002", "T-Shirt Obsessive", 75000, 16, "C2");
            dtSaveProduct.Rows.Add("R001", "Rok Mini", 82000, 26, "C3");
            dtSaveProduct.Rows.Add("J002", "Jeans Biru", 90000, 15, "C4");
            dtSaveProduct.Rows.Add("C001", "Celana Pendek Coklat", 60000, 11, "C4");
            dtSaveProduct.Rows.Add("C002", "Cawat Blink-blink", 100000, 1, "C5");
            dtSaveProduct.Rows.Add("R002", "Rocca Shirt", 50000, 8, "C2");

            dtCategory.Columns.Add("ID Category");
            dtCategory.Columns.Add("Category Name");
            dtCategory.Rows.Add("C1", "Jas");
            dtCategory.Rows.Add("C2", "T-Shirt");
            dtCategory.Rows.Add("C3", "Rok");
            dtCategory.Rows.Add("C4", "Celana");
            dtCategory.Rows.Add("C5", "Cawat");

            cbox_category.DataSource = dtCategory;
            cbox_category.DisplayMember = "Category Name";
            dtShowProduct = dtSaveProduct;
            dgv_Product.DataSource = dtShowProduct;
            dgv_Category.DataSource = dtCategory;
        }

        private void btn_Filter_Click(object sender, EventArgs e)
        {
            cbox_Filters.Enabled = true;
            cbox_Filters.DataSource = dtCategory;
            cbox_Filters.DisplayMember = "Category Name";
        }

        private void cbox_Filters_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbox_Filters.Enabled == true)
            {
                dtShowProduct = new DataTable();
                int indexNow = cbox_Filters.SelectedIndex;
                dtShowProduct.Columns.Add("ID Product");
                dtShowProduct.Columns.Add("Nama Product");
                dtShowProduct.Columns.Add("Harga");
                dtShowProduct.Columns.Add("Stock");
                dtShowProduct.Columns.Add("ID Category");
                foreach (DataRow dRow in dtSaveProduct.Rows)
                {
                    if (dRow["ID Category"] == dtCategory.Rows[indexNow]["ID Category"].ToString())
                    {
                        dtShowProduct.Rows.Add(dRow["ID Product"], dRow["Nama Product"], dRow["Harga"], dRow["Stock"], dRow["ID Category"]);
                    }
                }
                dgv_Product.DataSource = dtShowProduct;
            }
            else
            {
                dgv_Product.DataSource = dtSaveProduct;
            }




        }

        private void btn_All_Click(object sender, EventArgs e)
        {
            cbox_Filters.Enabled = false;
            dtShowProduct = dtSaveProduct;
            dgv_Product.DataSource = dtShowProduct;
        }

        private string penomoran(char angka)
        {
            int idCoba = 0;
            foreach (DataRow dRow in dtSaveProduct.Rows)
            {
                string ID = dRow["ID Product"].ToString();
                if (ID.Length > 1 && ID[0] == angka && int.TryParse(ID.Substring(1), out int idNumber))
                {
                    if (idNumber > idCoba)
                    {
                        idCoba = idNumber;
                    }
                }
            }
            return angka.ToString() + (idCoba + 1).ToString("000");

        }
        private void btn_addProduct_Click(object sender, EventArgs e)
        {
            if (tb_namaProduct.Text == "" || cbox_category.SelectedIndex == -1 || tb_harga.Text == "" || tb_stock.Text == "")
            {
                MessageBox.Show("All prompts must be filled");
            }
            else
            {
                string hasil = penomoran(tb_namaProduct.Text.ToUpper()[0]);
                int indexNow = cbox_category.SelectedIndex;
                dtSaveProduct.Rows.Add(hasil, tb_namaProduct.Text, tb_harga.Text, tb_stock.Text, dtCategory.Rows[indexNow]["ID Category"]);
                dtShowProduct = dtSaveProduct;
                dgv_Product.DataSource = dtShowProduct;
                tb_namaProduct.Text = "";
                tb_harga.Text = "";
                tb_stock.Text = "";
                cbox_category.SelectedIndex = -1;
            }
        }
        private void btn_editProduct_Click(object sender, EventArgs e)
        {
            if (tb_namaProduct.Text == "" || cbox_category.SelectedIndex == -1 || tb_harga.Text == "" || tb_stock.Text == "")
            {
                MessageBox.Show("All prompts must be filled");
            }
            else
            {
                if (Convert.ToInt32(tb_stock.Text) == 0)
                {
                    dtSaveProduct.Rows.RemoveAt(indexChosen);
                }
                else
                {
                    dtSaveProduct.Rows[indexChosen]["Nama Product"] = tb_namaProduct.Text;
                    dtSaveProduct.Rows[indexChosen]["Harga"] = tb_harga.Text;
                    dtSaveProduct.Rows[indexChosen]["Stock"] = tb_stock.Text;
                    dtSaveProduct.Rows[indexChosen]["ID Category"] = dtCategory.Rows[cbox_category.SelectedIndex]["ID Category"];

                }
                dtShowProduct = dtSaveProduct;
                dgv_Product.DataSource = dtShowProduct;
                tb_namaProduct.Text = "";
                tb_harga.Text = "";
                tb_stock.Text = "";
                cbox_category.SelectedIndex = -1;
            }
        }
        private void btn_removeProduct_Click(object sender, EventArgs e)
        {
            if (dgv_Product.SelectedCells.Count == 0)
            {
               
            }
            else
            {
                DataGridViewRow selectedRow = dgv_Product.SelectedRows[0];
                string selectedProductId = selectedRow.Cells["ID Product"].Value.ToString();

                int selectedIndexInMain = -1;
                for (int i = 0; i < dtSaveProduct.Rows.Count; i++)
                {
                    if (dtSaveProduct.Rows[i]["ID Product"].ToString() == selectedProductId)
                    {
                        selectedIndexInMain = i;
                        break;
                    }
                }
                if (selectedIndexInMain != -1)
                {
                    dtSaveProduct.Rows.RemoveAt(selectedIndexInMain);

                    if (cbox_Filters.Enabled)
                    {
                        cbox_Filters_SelectedIndexChanged(sender, e);
                    }
                    else
                    {
                        dgv_Product.DataSource = dtSaveProduct;
                    }
                    tb_namaProduct.Text = "";
                    cbox_category.SelectedIndex = -1;
                    tb_harga.Text = "";
                    tb_stock.Text = "";
                }
            }
            dgv_Product.ClearSelection();
        }
        private void tb_harga_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        private void tb_stock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        private void dgv_Product_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow selected = dgv_Product.Rows[e.RowIndex];
            tb_namaProduct.Text = selected.Cells[1].Value.ToString();
            tb_harga.Text = selected.Cells[2].Value.ToString();
            tb_stock.Text = selected.Cells[3].Value.ToString();
            string idCat = selected.Cells[4].Value.ToString();
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (dtCategory.Rows[i]["ID Category"].ToString() == idCat)
                {
                    cbox_category.SelectedIndex = i;
                }
            }
            indexChosen = e.RowIndex;
        }
        private void btn_addCategory_Click(object sender, EventArgs e)
        {
            if (tb_namaCategory.Text == "")
            {
                MessageBox.Show("All prompt must be filled");
            }
            else
            {
                bool ada = false;
                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    if (dtCategory.Rows[i][1].ToString() == tb_namaCategory.Text)
                    {
                        ada = true;
                        break;
                    }
                }
                if (ada == true)
                {
                    MessageBox.Show("Category Exists");
                }
                else
                {
                    dtCategory.Rows.Add("C" + counter, tb_namaCategory.Text);
                    counter++;
                    tb_namaCategory.Text = "";
                }
            }
        }

        private void btn_removeCategory_Click(object sender, EventArgs e)
        {
            if (tb_namaCategory.Text == "")
            {
                MessageBox.Show("All prompts must be filled");
            }
            else
            {
                string removeCategory = dtCategory.Rows[categoryChosen][0].ToString();
                dtCategory.Rows.RemoveAt(categoryChosen);
                dgv_Category.DataSource = dtCategory;
                cbox_category.DataSource = dtCategory;
                cbox_category.DisplayMember = "Nama Category";
                cbox_category.ValueMember = "ID Category";

                List<int> idRemover = new List<int>();
                for (int i = 0; i < dtSaveProduct.Rows.Count; i++)
                {
                    if (dtSaveProduct.Rows[i][4].ToString() == removeCategory)
                    {
                        idRemover.Add(i);
                    }
                }
                foreach (int i in idRemover)
                {
                    itemRemover(removeCategory);
                }
                dtShowProduct = dtSaveProduct;
                dgv_Product.DataSource = dtShowProduct;
            }
        }

        private void itemRemover(string tes)
        {
            List<int> idRemover = new List<int>();
            for (int i = 0; i < dtSaveProduct.Rows.Count; i++)
            {
                if (dtSaveProduct.Rows[i][4].ToString() == tes)
                {
                    idRemover.Add(i);
                    break;
                }
            }
            dtSaveProduct.Rows.RemoveAt(idRemover[0]);
        }

        private void dgv_Category_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow selected = dgv_Category.Rows[e.RowIndex];
            tb_namaCategory.Text = selected.Cells[1].Value.ToString();
            categoryChosen = e.RowIndex;
        }
        private void tb_namaCategory_TextChanged(object sender, EventArgs e)
        {

        }



        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void tb_stock_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}